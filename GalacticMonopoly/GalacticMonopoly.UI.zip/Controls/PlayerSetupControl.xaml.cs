﻿using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace GalacticMonopoly.UI.Views
{
    public partial class PlayerSetupControl : UserControl
    {
        public int PlayerIndex
        {
            get => _playerIndex;
            set
            {
                _playerIndex = value;
                PlayerLabel.Text = $"Gracz {value}:";
            }
        }

        public string PlayerName => NameBox.Text;

        public BitmapImage AvatarSource => (BitmapImage)AvatarImage.Source;

        private int _playerIndex;

        public PlayerSetupControl()
        {
            InitializeComponent();
        }
    }
}
