﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using GalacticMonopoly.Core.Game;

namespace GalacticMonopoly.UI.Views
{
    public partial class PlayerSetupPage : Page
    {
        private MainWindow _mainWindow;
        private List<PlayerSetupControl> _playerControls = new();

        public PlayerSetupPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
        }

        private void PlayerCountComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PlayerListPanel == null || PlayerCountComboBox.SelectedItem == null)
                return;

            PlayerListPanel.Children.Clear();
            _playerControls.Clear();

            int count = int.Parse(((ComboBoxItem)PlayerCountComboBox.SelectedItem).Content.ToString());

            for (int i = 0; i < count; i++)
            {
                var control = new PlayerSetupControl { PlayerIndex = i + 1 };
                _playerControls.Add(control);
                PlayerListPanel.Children.Add(control);
            }
        }

        private void StartGameButton_Click(object sender, RoutedEventArgs e)
        {
            var players = new List<Player>();

            foreach (var control in _playerControls)
            {
                if (string.IsNullOrWhiteSpace(control.PlayerName))
                {
                    MessageBox.Show($"Wprowadź nazwę gracza {control.PlayerIndex}.");
                    return;
                }

                players.Add(new Player
                {
                    Name = control.PlayerName,
                    Avatar = control.AvatarSource,
                    Money = 3000 // domyślna wartość
                });
            }

            _mainWindow.StartGame(players);
        }
    }
}
